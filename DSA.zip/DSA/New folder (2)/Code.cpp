#include <iostream>
#include <vector>
#include <algorithm>
#include <chrono>
#include <random>
#include <iomanip>
using namespace std;
void insertionSort(vector<int>& arr) {
    int n = arr.size();
    for (int i = 1; i < n; i++) {
        int key = arr[i];
        int j = i - 1;
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }
}
void merge(vector<int>& arr, int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;
    vector<int> L(n1), R(n2);
    for (int i = 0; i < n1; i++) L[i] = arr[left + i];
    for (int i = 0; i < n2; i++) R[i] = arr[mid + 1 + i];
    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) arr[k++] = L[i++];
        else arr[k++] = R[j++];
    }
    while (i < n1) arr[k++] = L[i++];
    while (j < n2) arr[k++] = R[j++];
}
void mergeSort(vector<int>& arr, int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        mergeSort(arr, left, mid);
        mergeSort(arr, mid + 1, right);
        merge(arr, left, mid, right);
    }
}

// (c) Bubble Sort
void bubbleSort(vector<int>& arr) {
    int n = arr.size();
    bool swapped;
    for (int i = 0; i < n - 1; i++) {
        swapped = false;
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                swap(arr[j], arr[j + 1]);
                swapped = true;
            }
        }
        if (!swapped) break;
    }
}

// (d) Heap Sort
void heapify(vector<int>& arr, int n, int i) {
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < n && arr[left] > arr[largest]) largest = left;
    if (right < n && arr[right] > arr[largest]) largest = right;

    if (largest != i) {
        swap(arr[i], arr[largest]);
        heapify(arr, n, largest);
    }
}

void heapSort(vector<int>& arr) {
    int n = arr.size();
    for (int i = n / 2 - 1; i >= 0; i--) heapify(arr, n, i);
    for (int i = n - 1; i > 0; i--) {
        swap(arr[0], arr[i]);
        heapify(arr, i, 0);
    }
}

// Function to generate random input arrays of various sizes
vector<int> generateRandomArray(int size) {
    vector<int> arr(size);
    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> distrib(1, 1000000);

    for (int i = 0; i < size; i++) arr[i] = distrib(gen);
    return arr;
}

// Function to measure the runtime of sorting algorithms
template<typename Func>
double measureTime(Func sortFunc, vector<int> arr) {
    auto start = chrono::high_resolution_clock::now();
    sortFunc(arr);
    auto end = chrono::high_resolution_clock::now();
    chrono::duration<double, milli> elapsed = end - start;
    return elapsed.count();  // Return time in milliseconds
}

// Function to run the algorithms on multiple inputs and calculate average times
void runTests() {
    vector<int> inputSizes = {500, 1000, 5000, 10000, 20000, 50000, 100000};
    int numTrials = 3;  // Run each test 3 times

    for (int size : inputSizes) {
        double insertionAvg = 0, mergeAvg = 0, bubbleAvg = 0, heapAvg = 0;

        for (int i = 0; i < numTrials; i++) {
            vector<int> arr1 = generateRandomArray(size);
            vector<int> arr2 = arr1;
            vector<int> arr3 = arr1;
            vector<int> arr4 = arr1;

            insertionAvg += measureTime(insertionSort, arr1);
            mergeAvg += measureTime([&](vector<int>& a) { mergeSort(a, 0, a.size() - 1); }, arr2);
            bubbleAvg += measureTime(bubbleSort, arr3);
            heapAvg += measureTime(heapSort, arr4);
        }

        insertionAvg /= numTrials;
        mergeAvg /= numTrials;
        bubbleAvg /= numTrials;
        heapAvg /= numTrials;

        cout << "Array Size: " << size << endl;
        cout << "Insertion Sort Avg Time: " << fixed << setprecision(3) << insertionAvg << " ms" << endl;
        cout << "Merge Sort Avg Time: " << fixed << setprecision(3) << mergeAvg << " ms" << endl;
        cout << "Bubble Sort Avg Time: " << fixed << setprecision(3) << bubbleAvg << " ms" << endl;
        cout << "Heap Sort Avg Time: " << fixed << setprecision(3) << heapAvg << " ms" << endl;
        cout << "----------------------------------------" << endl;
    }
}

int main() {
    runTests();
    return 0;
}