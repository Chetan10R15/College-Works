#include<stdio.h>
#include<stdlib.h>
void rank(int *arr,int n)
{
   static int c=0,brr[20];
   for(int i=0;i<n;i++)
   {
     brr[i]=arr[i];
   }
    for(int i=0;i<n;i++)
    {
        for(int j=i+1;j<n;j++)
        {
           if(brr[i]<brr[j])
           {
            brr[i]=c;
            c++;
           }
           brr[j]=c;
           c++;
        }
    }
    for(int i=0;i<n;i++)
    printf("%d ",brr[i]);
}
int main()
{
    int n,arr[20];
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
        scanf("%d ",&arr[i]);
    }
    rank(arr,n);
    return 0;
}