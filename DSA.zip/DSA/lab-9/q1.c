#include <stdio.h>
#include <stdlib.h>
struct AdjListNode {
    int dest;
    struct AdjListNode* next;
};
struct AdjList {
    struct AdjListNode* head;
};
struct Graph {
    int V;
    struct AdjList* array;
};
struct AdjListNode* newAdjListNode(int dest) {
    struct AdjListNode* newNode = (struct AdjListNode*) malloc(sizeof(struct AdjListNode));
    newNode->dest = dest;
    newNode->next = NULL;
    return newNode;
}
struct Graph* createGraph(int V) {
    struct Graph* graph = (struct Graph*) malloc(sizeof(struct Graph));
    graph->V = V;
    graph->array = (struct AdjList*) malloc(V * sizeof(struct AdjList));
    for (int i = 0; i < V; ++i)
    {
        graph->array[i].head = NULL;
    }
    return graph;
}
void addEdgeAdjList(struct Graph* graph, int src, int dest) {
    struct AdjListNode* newNode = newAdjListNode(dest);
    newNode->next = graph->array[src - 1].head;
    graph->array[src - 1].head = newNode;
    newNode = newAdjListNode(src);
    newNode->next = graph->array[dest - 1].head;
    graph->array[dest - 1].head = newNode;
}
void printAdjList(struct Graph* graph) {
    for (int i = 0; i < graph->V; ++i) {
        struct AdjListNode* temp = graph->array[i].head;
        printf("\n Adjacency list of vertex %d\n head ", i + 1);
        while (temp) {
            printf("-> %d", temp->dest);
            temp = temp->next;
        }
        printf("\n");
    }
}
void addEdgeAdjMatrix(int** adjMatrix, int src, int dest) {
    adjMatrix[src - 1][dest - 1] = 1;
    adjMatrix[dest - 1][src - 1] = 1;
}
void printAdjMatrix(int** adjMatrix, int V) {
    printf("\nAdjacency Matrix:\n");
    for (int i = 0; i < V; ++i) {
        for (int j = 0; j < V; ++j) {
            printf("%d ", adjMatrix[i][j]);
        }
        printf("\n");
    }
}

int main() {
    int V = 3;
    int E = 2;
    int edges[2][2] = {{1, 2}, {2, 3}};
    struct Graph* graph = createGraph(V);
    int** adjMatrix = (int**) malloc(V * sizeof(int*));
    for (int i = 0; i < V; ++i) {
        adjMatrix[i] = (int*) malloc(V * sizeof(int));
    }
    for (int i = 0; i < V; ++i) {
        for (int j = 0; j < V; ++j) {
            adjMatrix[i][j] = 0;
        }
    }
    for (int i = 0; i < E; ++i) {
        int src = edges[i][0];
        int dest = edges[i][1];
        addEdgeAdjList(graph, src, dest);
        addEdgeAdjMatrix(adjMatrix, src, dest);
    }
    printAdjList(graph);
    printAdjMatrix(adjMatrix,V);
    for (int i = 0; i < V; ++i) {
        free(adjMatrix[i]);
    }
    free(adjMatrix);
    return 0;
}
