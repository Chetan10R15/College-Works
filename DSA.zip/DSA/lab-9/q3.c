#include <stdio.h>
#include <stdlib.h>
struct AdjListNode {
    int dest;
    struct AdjListNode* next;
};
struct AdjList {
    struct AdjListNode* head;
};
struct Graph {
    int V;
    struct AdjList* array;
};
struct AdjListNode* newAdjListNode(int dest) {
    struct AdjListNode* newNode = (struct AdjListNode*)malloc(sizeof(struct AdjListNode));
    newNode->dest = dest;
    newNode->next = NULL;
    return newNode;
}
struct Graph* createGraph(int V) {
    struct Graph* graph = (struct Graph*)malloc(sizeof(struct Graph));
    graph->V = V;
    graph->array = (struct AdjList*)malloc(V * sizeof(struct AdjList));
    for (int i = 0; i < V; ++i)
        graph->array[i].head = NULL;
    return graph;
}
void addEdge(struct Graph* graph, int src, int dest) {
    struct AdjListNode* newNode = newAdjListNode(dest);
    newNode->next = graph->array[src].head;
    graph->array[src].head = newNode;
}
struct Graph* transposeGraphAdjList(struct Graph* graph) {
    struct Graph* transpose = createGraph(graph->V);
    for (int v = 0; v < graph->V; v++) {
        struct AdjListNode* temp = graph->array[v].head;
        while (temp) {
            addEdge(transpose, temp->dest, v);
            temp = temp->next;
        }
    }
    return transpose;
}
void printAdjList(struct Graph* graph) {
    for (int v = 0; v < graph->V; ++v) {
        struct AdjListNode* temp = graph->array[v].head;
        printf("\n Adjacency list of vertex %d\n head ", v);
        while (temp) {
            printf("-> %d", temp->dest);
            temp = temp->next;
        }
        printf("\n");
    }
}
void transposeGraphAdjMatrix(int** adjMatrix, int V, int** transposeMatrix) {
    for (int i = 0; i < V; i++) {
        for (int j = 0; j < V; j++) {
            transposeMatrix[j][i] = adjMatrix[i][j];
        }
    }
}
void printAdjMatrix(int** adjMatrix, int V) {
    for (int i = 0; i < V; ++i) {
        for (int j = 0; j < V; ++j) {
            printf("%d ", adjMatrix[i][j]);
        }
        printf("\n");
    }
}
int main() {
    int V = 4;
    struct Graph* graph = createGraph(V);
    addEdge(graph, 0, 1);
    addEdge(graph, 0, 2);
    addEdge(graph, 1, 2);
    addEdge(graph, 2, 0);
    addEdge(graph, 2, 3);
    printf("Original graph adjacency list:\n");
    printAdjList(graph);
    struct Graph* transpose = transposeGraphAdjList(graph);
    printf("\nTranspose graph adjacency list:\n");
    printAdjList(transpose);
    int** adjMatrix = (int**)malloc(V * sizeof(int*));
    int** transposeMatrix = (int**)malloc(V * sizeof(int*));
    for (int i = 0; i < V; i++)
    {
        adjMatrix[i] = (int*)malloc(V * sizeof(int));
        transposeMatrix[i] = (int*)malloc(V * sizeof(int));
    }
    adjMatrix[0][1] = 1; adjMatrix[0][2] = 1; adjMatrix[0][0] = 0; adjMatrix[0][3] = 0;
    adjMatrix[1][2] = 1; adjMatrix[1][0] = 0; adjMatrix[1][1] = 0; adjMatrix[1][3] = 0;
    adjMatrix[2][0] = 1; adjMatrix[2][1] = 0; adjMatrix[2][2] = 0; adjMatrix[2][3] = 1;
    adjMatrix[3][0] = 0; adjMatrix[3][1] = 0; adjMatrix[3][2] = 0; adjMatrix[3][3] = 0;
    printf("\nOriginal graph adjacency matrix:\n");
    printAdjMatrix(adjMatrix, V);
    transposeGraphAdjMatrix(adjMatrix, V, transposeMatrix);
    printf("\nTranspose graph adjacency matrix:\n");
    printAdjMatrix(transposeMatrix, V);
    for (int i = 0; i < V; i++) 
    {
        free(adjMatrix[i]);
        free(transposeMatrix[i]);
    }
    free(adjMatrix);
    free(transposeMatrix);
    return 0;
}
