#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
struct AdjListNode {
    int dest;
    struct AdjListNode* next;
};
struct AdjList {
    struct AdjListNode* head;
};
struct Graph {
    int V;
    struct AdjList* array;
};
struct Queue {
    int* items;
    int front, rear;
    int size;
};
struct Queue* createQueue(int capacity) {
    struct Queue* queue = (struct Queue*)malloc(sizeof(struct Queue));
    queue->items = (int*)malloc(capacity * sizeof(int));
    queue->front = -1;
    queue->rear = -1;
    queue->size = capacity;
    return queue;
}
bool isEmpty(struct Queue* queue) {
    return queue->rear == -1;
}
void enqueue(struct Queue* queue, int item) {
    if (queue->rear == queue->size - 1) {
        return;
    }
    if (queue->front == -1) queue->front = 0;
    queue->items[++queue->rear] = item;
}
int dequeue(struct Queue* queue) {
    if (isEmpty(queue)) {
        return -1;
    }
    int item = queue->items[queue->front];
    if (queue->front >= queue->rear) {
        queue->front = -1;
        queue->rear = -1;
    } else {
        queue->front++;
    }
    return item;
}
struct AdjListNode* newAdjListNode(int dest) {
    struct AdjListNode* newNode = (struct AdjListNode*)malloc(sizeof(struct AdjListNode));
    newNode->dest = dest;
    newNode->next = NULL;
    return newNode;
}
struct Graph* createGraph(int V) {
    struct Graph* graph = (struct Graph*)malloc(sizeof(struct Graph));
    graph->V = V;
    graph->array = (struct AdjList*)malloc(V * sizeof(struct AdjList));
    for (int i = 0; i < V; ++i) {
        graph->array[i].head = NULL;
    }
    return graph;
}
void addEdge(struct Graph* graph, int src, int dest) {
    struct AdjListNode* newNode = newAdjListNode(dest);
    newNode->next = graph->array[src].head;
    graph->array[src].head = newNode;
    newNode = newAdjListNode(src);
    newNode->next = graph->array[dest].head;
    graph->array[dest].head = newNode;
}
void BFS(struct Graph* graph, int startVertex) {
    bool* visited = (bool*)malloc(graph->V * sizeof(bool));
    int* parent = (int*)malloc(graph->V * sizeof(int));
    for (int i = 0; i < graph->V; i++) {
        visited[i] = false;
        parent[i] = -1;
    }
    struct Queue* queue = createQueue(graph->V);
    visited[startVertex] = true;
    enqueue(queue, startVertex);
    printf("BFS Tree:\n");
    while (!isEmpty(queue)) {
        int currentVertex = dequeue(queue);
        printf("Visited vertex: %d\n", currentVertex + 1);
        struct AdjListNode* temp = graph->array[currentVertex].head;

        while (temp) {
            int adjVertex = temp->dest;
            if (!visited[adjVertex]) {
                visited[adjVertex] = true;
                parent[adjVertex] = currentVertex;
                enqueue(queue, adjVertex);
            }
            temp = temp->next;
        }
    }
    printf("\nBFS Tree (parent -> child relationships):\n");
    for (int i = 0; i < graph->V; i++) {
        if (parent[i] != -1) {
            printf("%d -> %d\n", parent[i] + 1, i + 1);
        }
    }
    free(visited);
    free(parent);
    free(queue->items);
    free(queue);
}
int main() {
    int V = 5;
    struct Graph* graph = createGraph(V);
    addEdge(graph, 0, 1);
    addEdge(graph, 0, 4);
    addEdge(graph, 1, 2);
    addEdge(graph, 1, 3);
    addEdge(graph, 1, 4);
    addEdge(graph, 2, 3);
    addEdge(graph, 3, 4);
    BFS(graph, 0);
    return 0;
}
