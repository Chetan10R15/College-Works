#include<stdio.h>
#include<stdlib.h>
struct adjnode{
    int dest;
    struct adjnode* next;
};
struct adj{
    struct adjnode* head;
};
struct Graph{
    int v;
    struct adj* array;
};
struct adjnode* newadj(int dest){
    struct adjnode* newnode=(struct adjnode*)malloc(sizeof(struct adjnode));
    newnode->dest=dest;
    newnode->next=NULL;
    return newnode;
}
struct Graph* cgraph(int v)
{
    struct Graph* graph=(struct Graph*)malloc(sizeof(struct Graph));
    graph->v=v;
    graph->array=(struct adj*)malloc(v*sizeof(struct adj));
    for(int i=0;i<v;i++)
    {
        graph->array[i].head=NULL;
    }
    return graph;
}
void edgelist(struct Graph* graph,int s,int dest){
    struct adjnode* newnode=newadj(dest);
    newnode->next=graph->array[s-1].head;
    graph->array[s-1].head=newnode;
    newnode=newadj(s);
    newnode->next=graph->array[dest-1].head;
    graph->array[dest-1].head=newnode;
}
void print(struct Graph* graph){
    for(int i=0;i<graph->v;i++){
        struct adjnode* temp=graph->array[i].head;
        printf("adjacency list of vertex %d",i);
        while(temp){
            printf("%d",temp->dest);
            temp=temp->next;
        }
        printf("\n");
    }
}
void adjedgematrix(int **adjmatrix,int s,int dest){
    adjmatrix[s-1][dest-1]=1;
}
void printadjmat(int **adjmatrix,int v){
    for(int i=0;i<v;i++)
    {
        for(int j=0;j<v;j++)
        {
            printf("%d ",adjmatrix[i][j]);
        }
        printf("\n");
    }
}
int main()
{
    int v=3,e=2;
    int edges[2][2]={{1,2},{2,3}};
    struct Graph* graph=cgraph(v);
    int *adjmatrix=(int**)malloc(v*sizeof(int*));
    for(int i=0;i<v;i++){
    adjmatrix[i]=(int*)malloc(v*sizeof(int));
    }
     for (int i = 0; i < v; ++i) {
        for (int j = 0; j < v; ++j) {
            adjmatrix[i][j] = 0;
        }
    }
    for(int i=0;i<e;++i)
    {
    int s=edges[i][0];
    int dest=edges[i][1];
    edgelist(graph,s,dest);
    addedgematrix(adjmatrix,s,dest);
    }
    print(graph);
    printadjmat(adjmatrix,v);
    for (int i = 0; i < v; ++i) {
        free(adjmatrix[i]);
    }
    free(adjmatrix);
    return 0;
}