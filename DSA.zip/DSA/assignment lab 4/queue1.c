#include <stdio.h>
#include <stdlib.h>
#define MAX 100
typedef struct Queue {
    int arr[MAX];
    int front;
    int rear;
} Queue;
void initQueue(Queue *q) {
    q->front = -1;
    q->rear = -1;
}
int isEmpty(Queue *q) {
    return q->front == -1;
}
int isFull(Queue *q) {
    return q->rear == MAX - 1;
}
void enqueue(Queue *q, int item) {
    if (isFull(q)) {
        printf("Queue is full\n");
        return;
    }
    if (isEmpty(q)) {
        q->front = 0;
    }
    q->arr[++(q->rear)] = item;
    printf("Enqueued %d to the queue.\n", item);
}
int dequeue(Queue *q) {
    if (isEmpty(q)) {
        printf("Queue is empty\n");
        return -1;
    }
    int item = q->arr[q->front];
    if (q->front == q->rear) {
        q->front = -1;
        q->rear = -1;
    } else {
        q->front++;
    }
    return item;
}
int peek(Queue *q) {
    if (isEmpty(q)) {
        printf("Queue is empty\n");
        return -1;
    }
    return q->arr[q->front];
}
int size(Queue *q) {
    if (isEmpty(q)) {
        return 0;
    }
    return q->rear - q->front + 1;
}
int main() {
    Queue q;
    initQueue(&q);
    enqueue(&q, 10);
    enqueue(&q, 20);
    enqueue(&q, 30);
    printf("Front element is %d\n", peek(&q));
    printf("Queue size is %d\n", size(&q));
    printf("Dequeued element is %d\n", dequeue(&q));
    printf("Queue size is now %d\n", size(&q));  
    return 0;
}