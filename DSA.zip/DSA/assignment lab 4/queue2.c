#include <stdio.h>
#include <stdlib.h>
typedef struct Node {
    int data;
    struct Node* next;
} Node;
typedef struct Queue {
    Node* front;
    Node* rear;
} Queue;
Node* createNode(int data) {
    Node* newNode =(Node*)malloc(sizeof(Node));
    if (!newNode) {
        printf("Memory is empty\n");
        return NULL;
    }
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}
void initQueue(Queue* q) {
    q->front = NULL;
    q->rear = NULL;
}
int isEmpty(Queue* q) {
    return q->front == NULL;
}
void enqueue(Queue* q, int data) {
    Node* newNode = createNode(data);
    if (!newNode) {
        printf("Queue is full\n");
        return;
    }
    if (isEmpty(q)) {
        q->front = q->rear = newNode;
    } else {
        q->rear->next = newNode;
        q->rear = newNode;
    }
    printf("Enqueued %d to the queue.\n", data);
}
int dequeue(Queue* q) {
    if (isEmpty(q)) {
        printf("Queue is empty\n");
        return -1;
    }
    Node* temp = q->front;
    int data = temp->data;
    q->front = q->front->next;
    if (q->front == NULL) {
        q->rear = NULL;
    }
    free(temp);
    return data;
}
int peek(Queue* q) {
    if (isEmpty(q)) {
        printf("Queue is empty\n");
        return -1;
    }
    return q->front->data;
}
int size(Queue* q) {
    int c = 0;
    Node* temp = q->front;
    while (temp != NULL) {
        c++;
        temp = temp->next;
    }
    return c;
}
int main() {
    Queue q;
    initQueue(&q);
    enqueue(&q, 10);
    enqueue(&q, 20);
    enqueue(&q, 30);
    printf("Front element is %d\n", peek(&q));
    printf("Queue size is %d\n", size(&q));
    printf("Dequeued element is %d\n", dequeue(&q));
    printf("Queue size is now %d\n", size(&q));
    return 0;
}