#include <stdio.h>
#include <stdlib.h>
typedef struct Node {
    int data;
    struct Node* next;
} Node;
Node* create(int data) {
    Node* new = (Node*)malloc(sizeof(Node));
    if (!new) {
        printf("Memory doesnt exists\n");
        return NULL;
    }
    new->data = data;
    new->next = NULL;
    return new;
}
int isEmpty(Node* top) {
    return top == NULL;
}
void push(Node** top, int data) {
    Node* new = create(data);
    if (!new) {
        printf("Stack overflow\n");
        return;
    }
    new->next = *top;
    *top = new;
    printf("Pushed %d into the stack.\n", data);
}
int pop(Node** top) {
    if (isEmpty(*top)) {
        printf("Stack underflow\n");
        return -1;
    }
    Node* temp = *top;
    int poppedData = temp->data;
    *top = (*top)->next;
    free(temp);
    return poppedData;
}
int peek(Node* top) {
    if (isEmpty(top)) {
        printf("Stack is empty\n");
        return -1;
    }
    return top->data;
}
int size(Node* top) {
    int count = 0;
    Node* temp = top;
    while (temp != NULL) {
        count++;
        temp = temp->next;
    }
    return count;
}
int main() {
    Node* stack = NULL;
    push(&stack, 10);
    push(&stack, 20);
    push(&stack, 30);
    printf("Top element in stack is %d\n", peek(stack));
    printf("Stack size is %d\n", size(stack));
    printf("Popped element in stack is %d\n", pop(&stack));
    printf("Stack size is now %d\n", size(stack));
    return 0;
}