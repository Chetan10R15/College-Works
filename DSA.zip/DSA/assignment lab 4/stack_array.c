#include<stdio.h>
#include<stdlib.h>
struct stack {
    int size;
    int top;
    int arr[];
};
int isEmpty(struct stack*s)
{
return s->top==-1; 
}
int isFull(struct stack *s)
{
    return s->top==s->size-1; 
}
int push(struct stack *s,int value)
{
    if(isFull(s))
    {
        printf("the stack is full\n");
    }
    else{
        s->top++;
        s->arr[s->top+1]=value;
        return value;
    }
}
    int pop(struct stack *s,int value)
    {
        if(isEmpty(s))
        {
            printf("the stack is empty\n");
        }
        else{
            int value=s->arr[s->top];
            s->top-1;
        }
         return value;
    }
   
int main()
{
  struct stack *s;
  s->top=-1;
  isFull(&s);
  push(&s,15);
  printf("the inserted element in stack is %d\n ",push(s,15));
  isEmpty(&s);
  pop(&s,15);
  printf("the  popped element in stack is %d ",pop(s,15));
    return 0;
}