#include <stdio.h>
#include <stdlib.h>
void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}
void heap(int arr[], int n, int i)
{
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;
    if (left < n && arr[left] > arr[largest])
    {
        largest = left;
    }
    if (right < n && arr[right] > arr[largest])
    {
        largest = right;
    }
    if (largest != i)
    {
        swap(&arr[i], &arr[largest]);
        heap(arr, n, largest);
    }
}
void max_heap(int arr[], int n)
{
    int i;
    for (int i = n / 2 - 1; i >= 0; i--)
    {
        heap(arr, n, i);
    }
}
void heap_sort(int arr[], int n)
{
    max_heap(arr, n);
    for (int i = n - 1; i >= 0; i--)
    {
        swap(&arr[0], &arr[i]);
        heap(arr, i, 0);
    }
}
int main()
{
    int n, arr[20];
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d ", &arr[i]);
    }
    heap_sort(arr, n);
    for (int i = 0; i < n; i++)
    {
        printf("%d ", arr[i]);
    }
}