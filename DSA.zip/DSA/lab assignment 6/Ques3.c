#include <stdio.h>
#include <stdlib.h>
#define MAX_SIZE 100
typedef struct {
    int data[MAX_SIZE];
    int size;
} PriorityQueue;
void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}
void maxHeapify(PriorityQueue *Q, int i) {
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;
    if (left < Q->size && Q->data[left] > Q->data[largest])
        largest = left;
    if (right < Q->size && Q->data[right] > Q->data[largest])
        largest = right;
    if (largest != i) {
        swap(&Q->data[i], &Q->data[largest]);
        maxHeapify(Q, largest);
    }
}
void buildMaxHeap(PriorityQueue *Q) {
    int i;
    for (i = Q->size / 2 - 1; i >= 0; i--)
        maxHeapify(Q, i);
}
void INSERT(PriorityQueue *Q, int x) {
    Q->size++;
    Q->data[Q->size - 1] = x;
    int i = Q->size - 1;
    while (i > 0 && Q->data[i] > Q->data[(i - 1) / 2]) {
        swap(&Q->data[i], &Q->data[(i - 1) / 2]);
        i = (i - 1) / 2;
    }
}
int MAXIMUM(PriorityQueue *Q) {
    return Q->data[0];
}
int EXTRACT_MAX(PriorityQueue *Q) {
    int max = Q->data[0];
    Q->data[0] = Q->data[Q->size - 1];
    Q->size--;
    maxHeapify(Q, 0);
    return max;
}
void INCREASE_KEY(PriorityQueue *Q, int i, int k) {
    Q->data[i] = k;
    while (i > 0 && Q->data[i] > Q->data[(i - 1) / 2]) {
        swap(&Q->data[i], &Q->data[(i - 1) / 2]);
        i = (i - 1) / 2;
    }
}
int main() {
    PriorityQueue Q;
    Q.size = 0;
    INSERT(&Q, 10);
    INSERT(&Q, 5);
    INSERT(&Q, 15);
    INSERT(&Q, 3);
    INSERT(&Q, 20);
    printf("Maximum: %d\n", MAXIMUM(&Q));
    int max = EXTRACT_MAX(&Q);
    printf("Extracted maximum: %d\n", max);
    INCREASE_KEY(&Q, 2, 18);
    printf("Maximum after increasing key: %d\n", MAXIMUM(&Q));
    return 0;
}