#include<stdio.h>
#include<stdlib.h>
void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}
void heap(int A[], int n, int i) {
    int largest = i;         
    int left = 2 * i + 1;    
    int right = 2 * i + 2;   
    if (left < n && A[left] > A[largest])
        largest = left;
    if (right < n && A[right] > A[largest])
        largest = right;
    if (largest != i) {
        swap(&A[i],&A[largest]);  
        heap(A, n, largest);  
    }
}
void buildMaxHeap(int A[], int n) {
    for (int i = n / 2 - 1; i >= 0; i--) {
        heap(A, n, i);
    }
}
void print(int A[], int n) {
    for (int i = 0; i < n; ++i)
        printf("%d ",A[i]);
}
int main() {
    int A[] = {3, 9, 2, 1, 4, 5};
    int n = sizeof(A) / sizeof(A[0]);
    buildMaxHeap(A, n);
    printf("Max Heap array: \n");
    print(A, n);
    return 0;
}