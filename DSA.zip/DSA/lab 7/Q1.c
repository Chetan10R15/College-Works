#include <stdio.h>
#include <stdlib.h>
struct Node {
    int data;
    struct Node* left;
    struct Node* right;
};
struct Node* newNode(int data) {
    struct Node* node = (struct Node*)malloc(sizeof(struct Node));
    node->data = data;
    node->left = node->right = NULL;
    return node;
}
struct Node* insert(struct Node* node, int data) {
    if (node == NULL) return newNode(data);
    if (data < node->data)
        node->left = insert(node->left, data);
    else if (data > node->data)
        node->right = insert(node->right, data);
    return node;
}
int height(struct Node* node) {
    if (node == NULL)
        return 0;
    int leftHeight = height(node->left);
    int rightHeight = height(node->right);
    return (leftHeight > rightHeight ? leftHeight : rightHeight) + 1;
}
int isBalanced(struct Node* node) {
    if (node == NULL)
        return 1;
    int leftHeight = height(node->left);
    int rightHeight = height(node->right);
    if (abs(leftHeight - rightHeight) <= 1 && isBalanced(node->left) && isBalanced(node->right))
        return 1;
    return 0;
}
int isBST(struct Node* node, struct Node* left, struct Node* right) {
    if (node == NULL)
        return 1;
    if (left != NULL && node->data <= left->data)
        return 0;
    if (right != NULL && node->data >= right->data)
        return 0;
    return isBST(node->left, left, node) && isBST(node->right, node, right);
}
int isAVL(struct Node* node) {
    if (isBST(node, NULL, NULL) && isBalanced(node))
        return 1;
    return 0;
}

int main() {
    struct Node* root = NULL;
    root = insert(root, 10);
    root = insert(root, 20);
    root = insert(root, 5);
    root = insert(root, 6);
    root = insert(root, 3);
 root = insert(root, 2);
    if (isAVL(root))
        printf("The tree is an AVL tree.\n");
    else
        printf("The tree is not an AVL tree.\n");

    return 0;
}