#include <stdio.h>
#include <stdlib.h>

#define MAX 10000

int timer = 0;
int visited[MAX], disc[MAX], low[MAX], parent[MAX];

struct Node {
    int vertex;
    struct Node* next;
};

struct AdjList {
    struct Node* head;
};

struct Graph {
    int vertices;
    struct AdjList* array;
};

struct Node* newNode(int vertex) {
    struct Node* node = (struct Node*)malloc(sizeof(struct Node));
    node->vertex = vertex;
    node->next = NULL;
    return node;
}

struct Graph* createGraph(int vertices) {
    struct Graph* graph = (struct Graph*)malloc(sizeof(struct Graph));
    graph->vertices = vertices;
    graph->array = (struct AdjList*)malloc(vertices * sizeof(struct AdjList));
    for (int i = 0; i < vertices; i++)
        graph->array[i].head = NULL;
    return graph;
}

void addEdge(struct Graph* graph, int src, int dest) {
    struct Node* node = newNode(dest);
    node->next = graph->array[src].head;
    graph->array[src].head = node;

    node = newNode(src);
    node->next = graph->array[dest].head;
    graph->array[dest].head = node;
}

void DFS(struct Graph* graph, int u, int* hasCutEdge) {
    visited[u] = 1;
    disc[u] = low[u] = ++timer;
    struct Node* temp = graph->array[u].head;

    while (temp) {
        int v = temp->vertex;
        if (!visited[v]) {
            parent[v] = u;
            DFS(graph, v, hasCutEdge);
            low[u] = (low[u] < low[v]) ? low[u] : low[v];
            if (low[v] > disc[u]) {
                printf("Cut Edge: %d - %d\n", u, v);
                *hasCutEdge = 1;
            }
        } else if (v != parent[u])
            low[u] = (low[u] < disc[v]) ? low[u] : disc[v];
        temp = temp->next;
    }
}

void findCutEdges(struct Graph* graph) {
    for (int i = 0; i < graph->vertices; i++) {
        visited[i] = 0;
        parent[i] = -1;
    }
    int hasCutEdge = 0;
    for (int i = 0; i < graph->vertices; i++) {
        if (!visited[i])
            DFS(graph, i, &hasCutEdge);
    }
    if (!hasCutEdge)
        printf("none\n");
}

int main() {
    int vertices, edges, u, v;
    printf("Enter number of vertices and edges: ");
    scanf("%d %d", &vertices, &edges);

    struct Graph* graph = createGraph(vertices);
    printf("Enter each edge (u v):\n");
    for (int i = 0; i < edges; i++) {
        scanf("%d %d", &u, &v);
        addEdge(graph, u, v);
    }

    printf("Cut edges in the graph:\n");
    findCutEdges(graph);

    return 0;
}
