// #include<stdio.h>
// #include<math.h>
// int main()
// {
//     int n,a=0,arr[5],y=0,x;
//     scanf("%d",&n);
//     x=n;
//     while(n!=0)
//     {
//         arr[a]=n%10;
//         n=n/10;
//         a++;
//     }
//     for(int i=0;i<a;i++)
//     {
//         y=y+pow(arr[i],a);
//     }
//     if(y==x)
//     {
//         printf(" %d Armstrong Number",y);
//     }
//     else
//     {
//         printf(" %d Not an Armstrong Number",y);
//     }
//    return 0; 
// }
#include <stdio.h>
#include <math.h>
int main()
{
    int n, original, a = 0, arr[10], y = 0; // Increase array size to handle more digits
    scanf("%d", &n);
    // Save the original number for comparison
    original = n;
    // Extract digits and store in arr
    while (n != 0)
    {
        arr[a] = n % 10;
        n = n / 10;
        a++;
    }
    // Calculate the sum of digits raised to the power of 'a'
    for (int i = 0; i < a; i++)
    {
        y = y + pow(arr[i], a);
    }
    // Compare the computed sum with the original number
    if (y == original)
    {
        printf("%d is an Armstrong Number\n", original);
    }
    else
    {
        printf("%d is Not an Armstrong Number\n", original);
    }
    return 0;
}
