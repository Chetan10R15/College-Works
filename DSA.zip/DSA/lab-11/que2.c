#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#define INF INT_MAX
typedef struct Node {
    int vertex;
    int weight;
    struct Node* next;
} Node;
typedef struct Graph {
    int numVertices;
    Node** adjLists;
} Graph;
typedef struct Stack {
    int* array;
    int top;
} Stack;
Node* createNode(int vertex, int weight) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->vertex = vertex;
    newNode->weight = weight;
    newNode->next = NULL;
    return newNode;
}
Graph* createGraph(int vertices) {
    Graph* graph = (Graph*)malloc(sizeof(Graph));
    graph->numVertices = vertices;
    graph->adjLists = (Node*)malloc(vertices * sizeof(Node));
    for (int i = 0; i < vertices; i++) {
        graph->adjLists[i] = NULL;
    }
    return graph;
}
void addEdge(Graph* graph, int src, int dest, int weight) {
    Node* newNode = createNode(dest, weight);
    newNode->next = graph->adjLists[src];
    graph->adjLists[src] = newNode;
}
Stack* createStack(int vertices) {
    Stack* stack = (Stack*)malloc(sizeof(Stack));
    stack->array = (int*)malloc(vertices * sizeof(int));
    stack->top = -1;
    return stack;
}
void push(Stack* stack, int value) {
    stack->array[++stack->top] = value;
}
int pop(Stack* stack) {
    return stack->array[stack->top--];
}
int isEmpty(Stack* stack) {
    return stack->top == -1;
}
void topologicalSortUtil(Graph* graph, int v, int* visited, Stack* stack) {
    visited[v] = 1;
    Node* temp = graph->adjLists[v];
    while (temp != NULL) {
        if (!visited[temp->vertex]) {
            topologicalSortUtil(graph, temp->vertex, visited, stack);
        }
        temp = temp->next;
    }
    push(stack, v);
}
void topologicalSort(Graph* graph, Stack* stack) {
    int* visited = (int*)malloc(graph->numVertices * sizeof(int));
    for (int i = 0; i < graph->numVertices; i++) {
        visited[i] = 0;
    }
    for (int i = 0; i < graph->numVertices; i++) {
        if (!visited[i]) {
            topologicalSortUtil(graph, i, visited, stack);
        }
    }
    free(visited);
}
void shortestPath(Graph* graph, int src) {
    int V = graph->numVertices;
    int dist[V];
    for (int i = 0; i < V; i++) {
        dist[i] = INF;
    }
    dist[src] = 0;
    Stack* stack = createStack(V);
    topologicalSort(graph, stack);
    while (!isEmpty(stack)) {
        int u = pop(stack);

        if (dist[u] != INF) {
            Node* temp = graph->adjLists[u];
            while (temp != NULL) {
                if (dist[u] + temp->weight < dist[temp->vertex]) {
                    dist[temp->vertex] = dist[u] + temp->weight;
                }
                temp = temp->next;
            }
        }
    }

    printf("Vertex\tShortest Distance from Source\n");
    for (int i = 0; i < V; i++) {
        if (dist[i] == INF) {
            printf("%d\tINF\n", i);
        } else {
            printf("%d\t%d\n", i, dist[i]);
        }
    }
    free(stack->array);
    free(stack);
}
int main() {
    int V = 6;
    Graph* graph = createGraph(V);
    addEdge(graph, 0, 1, 5);
    addEdge(graph, 0, 2, 3);
    addEdge(graph, 1, 3, 6);
    addEdge(graph, 1, 2, 2);
    addEdge(graph, 2, 4, 4);
    addEdge(graph, 2, 5, 2);
    addEdge(graph, 2, 3, 7);
    addEdge(graph, 3, 4, -1);
    addEdge(graph, 4, 5, -2);
    shortestPath(graph, 0);
    for (int i = 0; i < V; i++) {
        free(graph->adjLists[i]);
    }
    free(graph->adjLists);
    free(graph);
    return 0;
}