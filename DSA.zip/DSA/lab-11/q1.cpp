// #include <iostream>
// #include <vector>
// #include <algorithm>
// using namespace std;
// class Graph {
//     int V;
//     vector<int> *adj;
//     void untill(int u, vector<bool> &visited, vector<int> &disc, vector<int> &low, int parent, vector<pair<int, int>> &bridges) {
//         static int time = 0;
//         visited[u] = true;
//         disc[u] = low[u] = ++time;
//         for (int v : adj[u]) {
//             if (!visited[v]) {
//                 untill(v, visited, disc, low, u, bridges);
//                 low[u] = min(low[u], low[v]);
//                 if (low[v] > disc[u]) {
//                     bridges.push_back({u, v});
//                 }
//             }
//             else if (v != parent) {
//                 low[u] = min(low[u], disc[v]);
//             }
//         }
//     }
// public:
//     Graph(int V) {
//         this->V = V;
//         adj = new vector<int>[V];
//     }
//     void addEdge(int u, int v) {
//         adj[u].push_back(v);
//         adj[v].push_back(u);
//     }
//     void cut() {
//         vector<bool> visited(V, false);
//         vector<int> disc(V, -1); 
//         vector<int> low(V, -1); 
//         vector<pair<int, int>> bridges;

//         for (int i = 0; i < V; i++) {
//             if (!visited[i]) {
//                 untill(i, visited, disc, low, -1, bridges);
//             }
//         }
//         if (bridges.empty()) {
//             cout << "none" << endl;
//         } else {
//             for (auto bridge : bridges) {
//                 cout << bridge.first << " - " << bridge.second << endl;
//             }
//         }
//     }
// };
// int main() {
//     int V = 5;
//     Graph g(V);
//     g.addEdge(0, 1);
//     g.addEdge(0, 2);
//     g.addEdge(1, 2);
//     g.addEdge(1, 3);
//     g.addEdge(3, 4);
//     cout << "Bridges or cut edges  in the graph are" << endl;
//     g.cut();
//     return 0;
// }