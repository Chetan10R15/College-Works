#include <stdio.h>
#include <stdlib.h>
struct Node {
    int data;
    struct Node *left, *right;
};
struct Node* newNode(int data) {
    struct Node* n = (struct Node*)malloc(sizeof(struct Node));
    n->data = data;
    n->left = n->right = NULL;
    return n;
}
struct Node* insert(struct Node* n, int data) {
    if (n== NULL)
        return newNode(data);
    if (data < n->data)
        n->left = insert(n->left, data);
    else if (data > n->data)
        n->right = insert(n->right, data);
    return n;
}
struct Node* minValue(struct Node* node) {
    struct Node* c = node;
    while ( c->left != NULL)
        c = c->left;
    return c;
}
struct Node* maxValue(struct Node* node) {
    struct Node* c = node;
    while (c->right != NULL)
        c = c->right;
    return c;
}
void preorder(struct Node* node) {
    if (node != NULL) {
        printf("%d ", node->data);
        preorder(node->left);
        preorder(node->right);
    }
}
void postorder(struct Node* node) {
    if (node != NULL) {
        postorder(node->left);
        postorder(node->right);
        printf("%d ", node->data);
    }
}
void inorder(struct Node* node) {
    if (node != NULL) {
        inorder(node->left);
        printf("%d ", node->data);
        inorder(node->right);
    }
}
struct Node* deleteNode(struct Node* root, int key) {
    if (root == NULL)
        return root;
    if (key < root->data)
        root->left = deleteNode(root->left, key);
    else if (key > root->data)
        root->right = deleteNode(root->right, key);
    else {
        if (root->left == NULL)
            return root->right;
        else if (root->right == NULL)
            return root->left;
        struct Node* temp = minValue(root->right);
        root->data = temp->data;
        root->right = deleteNode(root->right, temp->data);
    }
    return root;
}
struct Node* successor(struct Node* root, int key) {
    if (root == NULL)
        return NULL;
    if (key < root->data)
        return successor(root->left, key);
    if (key > root->data) {
        struct Node* succ = successor(root->right, key);
        if (succ != NULL)
            return succ;
        else
            return root;
    }
    if (root->right != NULL)
        return minValue(root->right);
    return NULL;
}
int height(struct Node* node) {
    if (node == NULL)
        return 0;
    int leftHeight = height(node->left);
    int rightHeight = height(node->right);
    return 1 + (leftHeight > rightHeight ? leftHeight : rightHeight);
}
int main() {
    struct Node* root = NULL;
    root = insert(root, 50);
    insert(root, 30);
    insert(root, 20);
    insert(root, 40);
    insert(root, 70);
    insert(root, 60);
    insert(root, 80);
    printf("Minimum value: %d\n", minValue(root)->data);
    printf("Maximum value: %d\n", maxValue(root)->data);
    printf("Preorder traversal: ");
    preorder(root);
    printf("\n");
    printf("Postorder traversal: ");
    postorder(root);
    printf("\n");
    printf("Inorder traversal: ");
    inorder(root);
    printf("\n");
    root = deleteNode(root, 50);
    printf("Inorder traversal after deletion: ");
    inorder(root);
    printf("\n");
    struct Node* succ = successor(root, 40);
    if (succ != NULL)
        printf("Successor of 40: %d\n", succ->data);
    else
        printf("Successor of 40 not found\n");

    // Find height
    printf("Height of the tree: %d\n", height(root));

    return 0;
}