#include<stdio.h>
#include<stdlib.h>
 struct Node{
    int data;
    struct Node *left, *right;
};
struct Node* new(int data){
    struct Node* n=(struct Node*)malloc(sizeof(struct Node));
    n->data=data;
    n->left=n->right=NULL;
    return n;
}
struct Node *insert(struct Node *n,int data)
{
    if(n==NULL)
    {
    return new(data);}
    if(data<n->data)
    {
        n->left=insert(n->left,data);
    }
    else if(data>n->data)
    {
        n->right=insert(n->right,data);
        return n;
    }
}
struct Node *min(struct Node *n){
    struct Node *c=n;
    while(c->left!=NULL)
    {
        c=c->left;
    }
    return c;
}
struct Node *max(struct Node *n){
    struct Node* c=n;
    while(c->right!=NULL)
    {
        c=c->right;
    }
    return c;
}
int main()
{
    struct Node *root=NULL;
    root=insert(root,10);
    insert(root,30);
    insert(root,5);
    printf("minimum value is %d\n",min(root->data));
    printf("maximum value is %d",max(root->data));
}