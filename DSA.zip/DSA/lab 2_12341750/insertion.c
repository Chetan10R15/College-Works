#include<stdio.h>
void insert(int arr[],int n,int k,int index)
{
    for(int i=n-1;i>=index;i--)
    {
        arr[i+1]=arr[i];
    }
    arr[index]=k;
}
int main()
{
    int arr[30],n,index,k;
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
    printf("enter the number to be inserted:");
    scanf("%d",&k);
    printf("enter the position at which the number is inserted:");
    scanf("%d",&index);
 insert(arr,n,k,index);
 n+=1;
 for(int i=0;i<n;i++)
 {
    printf("%d ",arr[i]);
 }
    return 0;
}