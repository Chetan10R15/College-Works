#include <stdio.h>
#include <stdlib.h>
struct Node {
    int data;
    struct Node* next;
};
// (a) Creating a new node
struct Node* create(int value) {
    struct Node* new = (struct Node*)malloc(sizeof(struct Node));
    new->data = value;
    new->next = NULL;
    return new;
}
//(b) Inserting a node at the beginning of the list
void begin(struct Node** head, int value) {
    struct Node* new = create(value);
    new->next = *head;
    *head = new;
}
// (c) Inserting a node at the end of the list
void end(struct Node** head, int value) {
    struct Node* new = create(value);
    if (*head == NULL) {
        *head = new;
        return;
    }
    struct Node* temp = *head;
    while (temp->next != NULL) {
        temp = temp->next;
    }
    temp->next = new;
}
//(d) Inserting a node before a node with a given value
void between(struct Node** head, int targetValue, int newValue) {
    struct Node* new = create(newValue);
    struct Node* temp = *head;
    while (temp->next != NULL && temp->next->data != targetValue) {
        temp = temp->next;
    }
    if (temp->next == NULL) {
        printf("Node with value %d not found.\n", targetValue);
        return;
    }
    new->next = temp->next;
    temp->next = new;
}
// (e) Deletion of node at beginning
void delete_B(struct Node** head) {
    if (*head == NULL) {
        printf("Cannot delete from empty list\n");
        return;
    }
    struct Node* temp = *head;
    *head = (*head)->next;
    free(temp);
}
// (f) Deletion of node at end
void delete_E(struct Node** head) {
    if (*head == NULL) {
        printf("Cannot delete from empty list\n");
        return;
    }
    if ((*head)->next == NULL) {
        free(*head);
        *head = NULL;
        return;
    }
    struct Node* temp = *head;
    while (temp->next->next != NULL) {
        temp = temp->next;
    }
    free(temp->next);
    temp->next = NULL;
}
//(g) Deletion of node with a given value
void delete_V(struct Node** head, int targetValue) {
    if (*head == NULL) {
        printf("Cannot delete from empty list\n");
        return;
    }
    if ((*head)->data == targetValue) {
        delete_B(head);
        return;
    }
    struct Node* temp = *head;
    while (temp->next != NULL && temp->next->data != targetValue) {
        temp = temp->next;
    }
    if (temp->next == NULL) {
        printf("Node with value %d not found.\n", targetValue);
        return;
    }
    struct Node* toDelete = temp->next;
    temp->next = temp->next->next;
    free(toDelete);
}
void display(struct Node* head) {
    struct Node* temp = head;
    while (temp != NULL) {
        printf("%d -> ", temp->data);
        temp = temp->next;
    }
    printf("NULL\n");
}
int main() {
    struct Node* head = NULL;
    begin(&head, 3);
    begin(&head, 2);
    begin(&head, 1);
    end(&head, 4);
    between(&head, 4, 5);

    printf("Linked List: ");
    display(head);

    delete_B(&head);
    delete_E(&head);
    delete_V(&head, 3);
    
printf("Linked List: ");
    display(head);
    return 0;
}