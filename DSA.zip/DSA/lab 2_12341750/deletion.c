#include<stdio.h>
void delete(int arr[],int n,int k)
{
    for(int i=k;i<n-1;i++)
    {
        arr[i]=arr[i+1];
    }
}
int main()
{
    int arr[50],n,index;
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
   printf("Enter the index of number to be deleted:");
   scanf("%d",&index);
   delete(arr,n,index);
   n-=1;
   for(int i=0;i<n;i++)
   {
    printf("%d ",arr[i]);
   }
    return 0;
}