#include <stdio.h>
#include <stdlib.h>
struct Node {
    int data;
    struct Node* next;
};
struct Node* rev_Recursive(struct Node* head) {
    if (head == NULL || head->next == NULL)
        return head;

    struct Node* new_head = rev_Recursive(head->next);
    head->next->next = head;
    head->next = NULL;
    return new_head;
}
void printList(struct Node* node) {
    while (node != NULL) {
        printf("%d ", node->data);
        node = node->next;
    }
    printf("\n");
}
int main() {
     struct Node* head = (struct Node*)malloc(sizeof(struct Node));
    struct Node* second= (struct Node*)malloc(sizeof(struct Node));
    struct Node* third= (struct Node*)malloc(sizeof(struct Node));
    struct Node* fourth = (struct Node*)malloc(sizeof(struct Node));
    struct Node* fifth= (struct Node*)malloc(sizeof(struct Node));
    head->data = 1;
    head->next = second;
    second->data = 2;
    second->next = third;
    third->data = 3;
    third->next = fourth;
    fourth->data = 4;
    fourth->next = fifth;
    fifth->data = 5;
    fifth->next = NULL;
    printf("Original Linked List: ");
    printList(head);
    struct Node* reversed_head = rev_Recursive(head);
    printf("Reversed Linked List by recursive method is: ");
    printList(reversed_head);
    return 0;
}