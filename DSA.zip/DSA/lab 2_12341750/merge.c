#include<stdio.h>
#include<stdlib.h>
void merge(int arr[], int brr[], int n1, int n2, int crr[])
{
	int i = 0, j = 0, k = 0;
	while(i<n1){
	crr[k++]=arr[i++];
	}
	while(j<n2){
	crr[k++]=brr[j++];
	}
	sort(arr,crr+n1+n2);
}

int main()
{
	int arr[] = {10,11,12};
	int n1=sizeof(arr)/sizeof(arr[0]);

	int brr[] = {2,3,5,9};
    int n2=sizeof(brr)/sizeof(brr[0]);

	int crr[n1+n2];
	merge(arr, brr, n1, n2, crr);

	for (int j=0; j < n1+n2; j++)
		printf("%d",crr[j]);

	return 0;
}