#include<stdio.h>
void sort(int arr[],int n)
{
 int k;
  for(int i=0;i<n-1;i++)
  {
    for(int j=0;j<n-i-1;j++)
    {
        if(arr[j]>arr[j+1])
        {
            k=arr[j];
            arr[j]=arr[j+1];
            arr[j+1]=k;
        }
    }
  }
}
int main()
{
    int a[20],b[20],c[50],n,m;
    scanf("%d %d",&n,&m);
    int k=n;
 for(int i=0;i<n;i++)
 {
    scanf("%d",&a[i]);
    c[i]=a[i];
 }
 for(int j=0;j<m;j++)
 {
    scanf("%d",&b[j]);
    c[k]=b[j];
    k++;
 }
 n=n+m;
 sort(c,n);
 for(int i=0;i<n;i++)
 {
    printf("%d ",c[i]);
 }
    return 0;
}