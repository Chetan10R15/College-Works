#include<stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* next;
};

struct Node* create(int new_data)
{
    struct Node* new_node
        = (struct Node*)malloc(sizeof(struct Node));
    new_node->data = new_data;
    new_node->next = NULL;
    return new_node;
}
struct Node* insertAtFront(struct Node* head, int new_data)
{
    struct Node* new_node = create(new_data);
    new_node->next = head;
    return new_node;
}

void List(struct Node* head)
{
    struct Node* curr = head;
    while (curr != NULL) {
        printf(" %d", curr->data);
        curr = curr->next;
    }
    printf("\n");
}


int main()
{
    struct Node* head = create(2);
    head->next = create(3);
    head->next->next = create(4);
    head->next->next->next = create(5);
    List(head);
    int data = 1;
    head = insertAtFront(head, data);
    List(head);
    return 0;
}