#include <bits/stdc++.h>
using namespace std;

class DisjointSet {
    vector<int> parent, rank;

public:
    DisjointSet(int n) {
        parent.resize(n);
        rank.resize(n, 1);
        for (int i = 0; i < n; i++) 
            parent[i] = i; 
    }

    int find(int i) {
        if (parent[i] != i)
            parent[i] = find(parent[i]); 
        return parent[i];
    }

    void unite(int x, int y) {
        int rootX = find(x);
        int rootY = find(y);

        if (rootX != rootY) {
            if (rank[rootX] < rank[rootY]) {
                parent[rootX] = rootY;
            } else if (rank[rootX] > rank[rootY]) {
                parent[rootY] = rootX;
            } else {
                parent[rootY] = rootX;
                rank[rootX]++;
            }
        }
    }
};

class Graph {
    vector<tuple<int, int, int>> edges;
    int V;

public:
    Graph(int V) : V(V) {}

    void addEdge(int x, int y, int w) {
        edges.emplace_back(w, x, y);
    }

    void kruskalsMST() {
        sort(edges.begin(), edges.end());
        DisjointSet ds(V);

        int mstWeight = 0;
        vector<tuple<int, int, int>> mstEdges;

        for (auto [w, x, y] : edges) {
            if (ds.find(x) != ds.find(y)) {
                ds.unite(x, y);
                mstWeight += w;
                mstEdges.emplace_back(w, x, y);
            }
        }

        cout << "Edges in Minimum Spanning Tree (Kruskal's):\n";
        for (const auto& [w, u, v] : mstEdges)
            cout << u << " -- " << v << " with weight: " << w << endl;

        cout << "Total Weight of MST: " << mstWeight << endl;
    }

    void primsMST() {
        vector<vector<pair<int, int>>> adj(V);
        for (const auto& [w, u, v] : edges) {
            adj[u].emplace_back(v, w);
            adj[v].emplace_back(u, w);
        }

        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<>> pq;
        vector<bool> visited(V, false);
        vector<int> parent(V, -1);

        int mstWeight = 0;
        vector<tuple<int, int, int>> mstEdges;

        pq.push({0, 0}); 

        while (!pq.empty()) {
            auto [wt, u] = pq.top();
            pq.pop();

            if (visited[u])
                continue;

            visited[u] = true;
            mstWeight += wt;

            if (parent[u] != -1) 
                mstEdges.emplace_back(wt, parent[u], u);

            for (auto [v, weight] : adj[u]) {
                if (!visited[v]) {
                    pq.push({weight, v});
                    if (parent[v] == -1) 
                        parent[v] = u;
                }
            }
        }

        cout << "Edges in Minimum Spanning Tree (Prim's):\n";
        for (const auto& [wt, u, v] : mstEdges)
            cout << u << " -- " << v << " with weight: " << wt << endl;

        cout << "Total Weight of MST: " << mstWeight << endl;
    }
};

int main() {
    Graph g(4);
    g.addEdge(0, 1, 10);
    g.addEdge(1, 3, 15);
    g.addEdge(2, 3, 4);
    g.addEdge(2, 0, 6);
    g.addEdge(0, 3, 5);

    cout << "Using Kruskal's Algorithm:\n";
    g.kruskalsMST();

    cout << "\nUsing Prim's Algorithm:\n";
    g.primsMST();
    return 0;
}
