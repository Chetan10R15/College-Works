#include <stdio.h>
#include <stdlib.h>
#define MAX_NODES 100
struct Node {
    int vertex;
    struct Node* next;
};
struct Graph {
    int numVertices;
    struct Node** adjLists;
    int* visited;
};
struct Stack {
    int top;
    int items[MAX_NODES];
};
struct Node* createNode(int v) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->vertex = v;
    newNode->next = NULL;
    return newNode;
}
struct Graph* createGraph(int vertices) {
    struct Graph* graph = (struct Graph*)malloc(sizeof(struct Graph));
    graph->numVertices = vertices;

    graph->adjLists = (struct Node**)malloc(vertices * sizeof(struct Node*));
    graph->visited = (int*)malloc(vertices * sizeof(int));

    for (int i = 0; i < vertices; i++) {
        graph->adjLists[i] = NULL;
        graph->visited[i] = 0;
    }

    return graph;
}
void addEdge(struct Graph* graph, int src, int dest) {
    struct Node* newNode = createNode(dest);
    newNode->next = graph->adjLists[src];
    graph->adjLists[src] = newNode;
}
void push(struct Stack* stack, int v) {
    stack->items[++stack->top] = v;
}

int pop(struct Stack* stack) {
    return stack->items[stack->top--];
}
void topologicalSortUtil(struct Graph* graph, int v, struct Stack* stack) {
    graph->visited[v] = 1;
    
    struct Node* adjList = graph->adjLists[v];
    struct Node* temp = adjList;

    while (temp != NULL) {
        int adjVertex = temp->vertex;
        if (!graph->visited[adjVertex]) {
            topologicalSortUtil(graph, adjVertex, stack);
        }
        temp = temp->next;
    }
    push(stack, v);
}
void topologicalSort(struct Graph* graph) {
    struct Stack* stack = (struct Stack*)malloc(sizeof(struct Stack));
    stack->top = -1;
    for (int i = 0; i < graph->numVertices; i++) {
        if (!graph->visited[i]) {
            topologicalSortUtil(graph, i, stack);
        }
    }
    printf("Topological Sort: ");
    while (stack->top != -1) {
        printf("%d ", pop(stack));
    }
    printf("\n");

    free(stack);
}
int main() {
    int vertices = 6;
    struct Graph* graph = createGraph(vertices);
    addEdge(graph, 5, 2);
    addEdge(graph, 5, 0);
    addEdge(graph, 4, 0);
    addEdge(graph, 4, 1);
    addEdge(graph, 2, 3);
    addEdge(graph, 3, 1);
    topologicalSort(graph);
    for (int i = 0; i < vertices; i++) {
        free(graph->adjLists[i]);
    }
    free(graph->adjLists);
    free(graph->visited);
    free(graph);
    return 0;
}