#include <stdio.h>
#include <stdlib.h>
#define MAX_NODES 100
struct Node {
    int vertex;
    struct Node* next;
};
struct Graph {
    int numVertices;
    struct Node** adjLists;
    int* visited;
    int* recursionStack;
};
struct Node* createNode(int v) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->vertex = v;
    newNode->next = NULL;
    return newNode;
}
struct Graph* createGraph(int vertices) {
    struct Graph* graph = (struct Graph*)malloc(sizeof(struct Graph));
    graph->numVertices = vertices;

    graph->adjLists = (struct Node**)malloc(vertices * sizeof(struct Node*));
    graph->visited = (int*)malloc(vertices * sizeof(int));
    graph->recursionStack = (int*)malloc(vertices * sizeof(int));
    for (int i = 0; i < vertices; i++) {
        graph->adjLists[i] = NULL;
        graph->visited[i] = 0;
        graph->recursionStack[i] = 0;
    }

    return graph;
}
void addEdge(struct Graph* graph, int src, int dest) {
    struct Node* newNode = createNode(dest);
    newNode->next = graph->adjLists[src];
    graph->adjLists[src] = newNode;
}
int isCyclicUtil(struct Graph* graph, int v) {
    if (!graph->visited[v]) {
        graph->visited[v] = 1;
        graph->recursionStack[v] = 1;
        struct Node* temp = graph->adjLists[v];
        while (temp != NULL) {
            int adjVertex = temp->vertex;
            if (!graph->visited[adjVertex] && isCyclicUtil(graph, adjVertex)) {
                return 1;
            } else if (graph->recursionStack[adjVertex]) {
                return 1;
            }
            temp = temp->next;
        }
    }
    graph->recursionStack[v] = 0;
    return 0;
}
int isDAG(struct Graph* graph) {
    for (int i = 0; i < graph->numVertices; i++) {
        if (!graph->visited[i]) {
            if (isCyclicUtil(graph, i)) {
                return 0;
            }
        }
    }
    return 1;
}
int main() {
    int vertices = 6;
    struct Graph* graph = createGraph(vertices);
    addEdge(graph, 5, 2);
    addEdge(graph, 5, 0);
    addEdge(graph, 4, 0);
    addEdge(graph, 4, 1);
    addEdge(graph, 2, 3);
    addEdge(graph, 3, 5);
    if (isDAG(graph)) {
        printf("The graph is a DAG\n");
    } else {
        printf("The graph is not a DAG\n");
    }
    for (int i = 0; i < vertices; i++) {
        free(graph->adjLists[i]);
    }
    free(graph->adjLists);
    free(graph->visited);
    free(graph->recursionStack);
    free(graph);
    return 0;
}