#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;
enum EdgeType { TREE, BACK, FORWARD, CROSS };
struct Edge {
    int u, v;
    EdgeType type;
};
void dfs(int u, vector<vector<int>>& adj, vector<bool>& visited, vector<int>& discovery, vector<int>& finish, int& time, vector<Edge>& edges) {
    visited[u] = true;
    discovery[u] = ++time;
    for (int v : adj[u]) {
        if (!visited[v]) {
            edges.push_back({u, v, TREE});
            dfs(v, adj, visited, discovery, finish, time, edges);
        } else if (discovery[u] < discovery[v]) {
            edges.push_back({u, v, FORWARD});
        } else if (finish[v] == 0) {
            edges.push_back({u, v, BACK});
        } else {
            edges.push_back({u, v, CROSS});
        }
    }
    finish[u] = ++time;
}
int main() {
    int n, e;
    cin >> n >> e;
    vector<vector<int>> adj(n);
    for (int i = 0; i < e; i++) {
        int u, v;
        cin >> u >> v;
        adj[u].push_back(v);
    }
    vector<bool> visited(n, false);
    vector<int> discovery(n, 0), finish(n, 0);
    vector<Edge> edges;
    int time = 0;
    for (int i = 0; i < n; i++) {
        if (!visited[i]) dfs(i, adj, visited, discovery, finish, time, edges);
    }
    for (const auto& edge : edges) {
        cout << "Edge (" << edge.u << ", " << edge.v << "): ";
        if (edge.type == TREE) cout << "Tree Edge\n";
        else if (edge.type == BACK) cout << "Back Edge\n";
        else if (edge.type == FORWARD) cout << "Forward Edge\n";
        else if (edge.type == CROSS) cout << "Cross Edge\n";
    }
    return 0;
}