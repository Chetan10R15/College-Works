#include <stdio.h>
#include <stdlib.h>
#define MAX 100
int visited[MAX];
int parent[MAX];
int discovery[MAX];
int finish[MAX];
int time = 0;
typedef struct Node {
    int vertex;
    struct Node* next;
} Node;
typedef struct Graph {
    int numVertices;
    Node** adjLists;
} Graph;
Node* createNode(int v) {
    Node* newNode = malloc(sizeof(Node));
    newNode->vertex = v;
    newNode->next = NULL;
    return newNode;
}
Graph* createGraph(int vertices) {
    Graph* graph = malloc(sizeof(Graph));
    graph->numVertices = vertices;
    graph->adjLists = malloc(vertices * sizeof(Node*));
    for (int i = 0; i < vertices; i++)
        graph->adjLists[i] = NULL;
    return graph;
}
void addEdge(Graph* graph, int src, int dest) {
    Node* newNode = createNode(dest);
    newNode->next = graph->adjLists[src];
    graph->adjLists[src] = newNode;
}
void dfs(Graph* graph, int v) {
    visited[v] = 1;
    discovery[v] = ++time;
    Node* temp = graph->adjLists[v];
    while (temp) {
        int u = temp->vertex;
        if (!visited[u]) {
            parent[u] = v;
            printf("Tree Edge: %d -> %d\n", v, u);
            dfs(graph, u);
        } else if (visited[u] && discovery[u] < discovery[v] && parent[v] != u)
            printf("Back Edge: %d -> %d\n", v, u);
        else if (visited[u] && discovery[u] > discovery[v])
            printf("Forward Edge: %d -> %d\n", v, u);
        else if (visited[u] && discovery[u] < discovery[v])
            printf("Cross Edge: %d -> %d\n", v, u);
        temp = temp->next;
    }
    finish[v] = ++time;
}
void classifyEdges(Graph* graph) {
    for (int i = 0; i < graph->numVertices; i++)
        if (!visited[i])
            dfs(graph, i);
}
int main() {
    int vertices, edges, src, dest;
    printf("Enter the number of vertices: ");
    scanf("%d", &vertices);
    Graph* graph = createGraph(vertices);
    printf("Enter the number of edges: ");
    scanf("%d", &edges);
    for (int i = 0; i < edges; i++) {
        scanf("%d %d", &src, &dest);
        addEdge(graph, src, dest);
    }
    classifyEdges(graph);
    return 0;
}