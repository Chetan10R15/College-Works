def booth_algorithm(n, b1, b2):
    def decimal(bin_str, n):
        if bin_str[0] == '1':
            return int(bin_str, 2) - (1 << n)
        else:
            return int(bin_str, 2)
    a1=decimal(b1, n)
    a2=decimal(b2, n)
    a3= 0
    a4 = 0
    a5 = n
    while a5 > 0:
        if (a2 & 1) == 1 and a4 == 0:
            a3 = a3 - a1
        elif (a2 & 1) == 0 and a4 == 1:
            a3 = a3 + a1
        a3, a2, a4 = (a3 >> 1), (a2 >> 1) | ((a3 & 1) << (n - 1)), (a2 & 1)
        a5 -= 1
    ans = (a3 << n) | a2
    ans_bin = format(ans & ((1 << (2 * n)) - 1), f'0{2 * n}b')
    
    return ans_bin
n =int(input("Enter the number of bits:"))
a = input("enter the First number:")
b = input("Enter the second number:")

ans= booth_algorithm(n,a, b)
print("Answer of Booths algorithm is :",ans) 