import sys

def binary_to_int(binary_str):
    return int(binary_str, 2)

def int_to_binary(integer, num_bits):
    binary_str = bin(integer)[2:]
    return binary_str.zfill(num_bits)

def float_add_subtract(n, m, S1, S2, E1, E2, flag):
    # 1. Handle zero cases
    if S1 == '0' * n and E1 == '0' * m:
        return S2, E2, None if flag == 0 else invert_sign(S2), E2, None
    if S2 == '0' * n and E2 == '0' * m:
        return S1, E1, None

    # 2. Subtraction: Invert S2 if flag is 1
    if flag == 1:
        S2 = invert_sign(S2)

    # 3. Exponent comparison and alignment
    E1_int = binary_to_int(E1)
    E2_int = binary_to_int(E2)

    if E1_int < E2_int:
        shift_amount = E2_int - E1_int
        S1 = shift_right(S1, shift_amount)
        E1 = E2
    elif E2_int < E1_int:
        shift_amount = E1_int - E2_int
        S2 = shift_right(S2, shift_amount)
        E2 = E1

    # 4. Significand addition/subtraction
    result_significand = add_significands(S1, S2)

    # 5. Normalization
    result_significand, result_exponent, overflow = normalize(result_significand, E1)

    # 6. Rounding (truncation)
    result_significand = round_result(result_significand)

    # 7. Overflow/Underflow check
    if overflow:
        return None, None, "Exponent Overflow"

    result_exponent_int = binary_to_int(result_exponent)
    min_exponent = 0  # Adjust if your minimum exponent is not 0
    if result_exponent_int < min_exponent:
        return None, None, "Exponent Underflow"

    return result_significand, result_exponent, None

def invert_sign(S):
    return ''.join(['1' if bit == '0' else '0' for bit in S])

def shift_right(S, amount):
    return '0' * amount + S[:-amount] if amount < len(S) else '0' * len(S)

def add_significands(S1, S2):
    carry = 0
    result = ""
    max_len = max(len(S1), len(S2))

    S1 = S1.zfill(max_len)
    S2 = S2.zfill(max_len)

    for i in range(max_len - 1, -1, -1):
        bit_sum = int(S1[i]) + int(S2[i]) + carry
        result = str(bit_sum % 2) + result
        carry = bit_sum // 2

    if carry:
        result = "1" + result
    return result

def normalize(S, E):
    if S == '0' * len(S):
        return S, E, False

    leading_zeros = 0
    for bit in S:
        if bit == '0':
            leading_zeros += 1
        else:
            break

    if leading_zeros > 0:
        S = S[leading_zeros:] + '0' * leading_zeros
        E_int = binary_to_int(E)
        E_int -= leading_zeros

        if E_int < 0:  # Underflow check during normalization
            return '0' * len(S), '0' * len(E), True

        E = int_to_binary(E_int, len(E))
    elif len(S) > len(S1):  # Check if we need to shift right (overflow case)
        E_int = binary_to_int(E)
        E_int += 1
        if E_int >= 2**len(E):  # Overflow check during normalization
            return '1' * len(S), '1' * len(E), True

        E = int_to_binary(E_int, len(E))
        return S[1:], E, True

    return S, E, False

def round_result(S):
    return S  # Basic truncation rounding


# Get input from the user
n = int(input("Enter the significand size (n): "))
m = int(input("Enter the exponent size (m): "))
S1 = input("Enter the significand S1: ")
S2 = input("Enter the significand S2: ")
E1 = input("Enter the exponent E1: ")
E2 = input("Enter the exponent E2: ")
flag = int(input("Enter 0 for addition, 1 for subtraction: "))

# Perform the calculation
result_significand, result_exponent, error_message = float_add_subtract(n, m, S1, S2, E1, E2, flag)

# Print the results
if error_message:
    print("Error:", error_message)
else:
    print("Result Significand:", result_significand)
    print("Result Exponent:", result_exponent)