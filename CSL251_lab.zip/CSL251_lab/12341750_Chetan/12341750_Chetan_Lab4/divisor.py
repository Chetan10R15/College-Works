def AddSub(A: str, B: str, n: int, oper: str) -> str:
    if len(A) != n or len(B) != n:
        raise ValueError("Both A and B must be n-bit binary strings.")
    
    int_A = int(A, 2) - (1 << n) if A[0] == '1' else int(A, 2)
    int_B = int(B, 2) - (1 << n) if B[0] == '1' else int(B, 2)

    if oper == 'add':
        ans = int_A + int_B
    elif oper == 'sub':
        ans = int_A - int_B
    else:
        raise ValueError("Invalid operation. Use 'add' or 'sub'.")

    ans = (ans + (1 << n)) % (1 << n) - (1 << n) if ans < 0 else ans % (1 << n)

    ans_bin = bin(ans & ((1 << n) - 1))[2:].zfill(n)
    return ans_bin

def twos_complement(binary: str) -> str:
    n = len(binary)
    # Inversing the bits
    i = ''.join('1' if bit == '0' else '0' for bit in binary)
    # Add 1 to the inverted binary number
    twos_com = bin(int(i, 2) + 1)[2:]
    return twos_com.zfill(n)

def binary_division(n: int, M: str, Q: str):
    A = "0" * n  # Remainder (initialized to 0)
    Q = Q.zfill(n)  # Ensuring Q is n bits
    M = M.zfill(n)  # Ensuring M is n bits
    Count = n

    while Count > 0:
        # Left shift A and Q
        A = A[1:] + Q[0]  # Shift left A
        Q = Q[1:] + "0"  # Shift left Q

        # A = A - M
        A = AddSub(A, M,n, "sub")

        if A[0] == "1":  # If A < 0 (most significant bit is 1)
            Q = Q[:-1] + "0"  # Set Q_0 to 0
            A = AddSub(A, M,n,"add")  # Restore A (A = A + M)
        else:
            Q = Q[:-1] + "1"  # Set Q_0 to 1

        # Decrement Count
        Count -= 1

    return Q, A  # Q is the quotient, A is the remainder

n = int(input("Enter the number of bits:"))  # Number of bits
Q = input('Enter the divident:')  # Dividend
M = input('Enter the divisor:')  # Divisor
quotient, remainder = binary_division(n, M, Q)
print("Quotient:", quotient)
print("Remainder:", remainder)