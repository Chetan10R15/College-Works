def AddSub(A: str, B: str, n: int, oper: str) -> str:
    if len(A) != n or len(B) != n:
        raise ValueError("Both A and B must be n-bit binary strings.")
    
    int_A = int(A, 2) - (1 << n) if A[0] == '1' else int(A, 2)
    int_B = int(B, 2) - (1 << n) if B[0] == '1' else int(B, 2)

    if oper == 'add':
        ans = int_A + int_B
    elif oper == 'sub':
        ans = int_A - int_B
    else:
        raise ValueError("Invalid operation. Use 'add' or 'sub'.")

    ans = (ans + (1 << n)) % (1 << n) - (1 << n) if ans < 0 else ans % (1 << n)

    ans_bin = bin(ans & ((1 << n) - 1))[2:].zfill(n)
    return ans_bin

def arithmetic_right_shift(A, Q, Q_minus1):
   
    combined = A + Q + Q_minus1
    shifted = combined[0] + combined[:-1]
    return shifted[:len(A)], shifted[len(A):-1], shifted[-1]

def booths_algorithm(M, Q, n):
   
    if len(M) != n or len(Q) != n:
        raise ValueError("M and Q must be n-bit binary strings.")

    A = '0' * n  # Accumulator (n-bit binary, initially 0)
    Q_minus1 = '0'  # Previous Q_0 (initially 0)
    Count = n

    while Count > 0:
        Q0_Q_minus1 = Q[-1] + Q_minus1

        if Q0_Q_minus1 == '10':
            # A = A - M
            A = AddSub(A, M,n,"sub")
        elif Q0_Q_minus1 == '01':
            # A = A + M
            A = AddSub(A, M,n, "add")

        A, Q, Q_minus1 = arithmetic_right_shift(A, Q, Q_minus1)

        # Decrease count
        Count -= 1

    # Combine A and Q for the last product
    product = A + Q

    def twos_complement_to_int(bin_str):
        if bin_str[0] == '1':
            return int(bin_str, 2) - (1 << len(bin_str))
        else:
            return int(bin_str, 2)

    def int_to_twos_complement(value, bits):
        if value < 0:
            value = (1 << bits) + value
        return format(value & ((1 << bits) - 1), f'0{bits}b')

    product_value = twos_complement_to_int(product)
    return int_to_twos_complement(product_value, 2 * n)

if __name__ == "__main__":
    n =int(input("Enter the no. of bits:"))
    M = input("Enter the first number: ")
    Q = input("enter the second number: ")
    

    product = booths_algorithm(M, Q, n)
    print("Product: ",product)
    print("Product in decimal: ",int(product,2))
