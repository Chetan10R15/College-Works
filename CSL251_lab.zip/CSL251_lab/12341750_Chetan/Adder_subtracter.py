def AddSub(A: str, B: str, n: int, oper: str) -> str:
    if len(A) != n or len(B) != n:
        raise ValueError("Both A and B must be n-bit binary strings.")
    
    int_A = int(A, 2) - (1 << n) if A[0] == '1' else int(A, 2)
    int_B = int(B, 2) - (1 << n) if B[0] == '1' else int(B, 2)

    if oper == 'add':
        ans = int_A + int_B
    elif oper == 'sub':
        ans = int_A - int_B
    else:
        raise ValueError("Invalid operation. Use 'add' or 'sub'.")

    ans = (ans + (1 << n)) % (1 << n) - (1 << n) if ans < 0 else ans % (1 << n)

    ans_bin = bin(ans & ((1 << n) - 1))[2:].zfill(n)
    return ans_bin

if __name__ == "__main__":
    n =int(input("Enter the no. of bits:"))
    M = input("Enter the first number: ")
    Q = input("enter the second number: ")
print('The sum of numbers is:', AddSub(M, Q, n, 'add'))
print( 'The difference of numbers is:',AddSub(M, Q, n, 'sub'))