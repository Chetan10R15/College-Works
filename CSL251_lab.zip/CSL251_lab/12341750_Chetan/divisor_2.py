def AddSub(A: str, B: str, operation: str) -> str:
    # Ensure both A and B are the same length
    n = max(len(A), len(B))
    A = A.zfill(n)
    B = B.zfill(n)

    if operation == "sub":
        # Compute the 2's complement of B for subtraction
        B = twos_complement(B)

    # Perform binary addition
    result = (int(A, 2) + int(B, 2))

    # Handle overflow for n-bit 2's complement numbers
    if result >= (1 << n):
        result -= (1 << n) * 2
    elif result < -(1 << (n - 1)):
        result += (1 << n) * 2

    # Convert result back to binary and adjust to n bits
    result = bin(result & ((1 << n) - 1))[2:]
    return result.zfill(n)

def twos_complement(binary: str) -> str:
    n = len(binary)
    # Convert to integer, negate, and adjust to n bits
    value = int(binary, 2)
    if binary[0] == '1':
        value -= (1 << n)
    twos_comp = (-value) & ((1 << n) - 1)

    # Convert back to binary and ensure n bits
    return bin(twos_comp)[2:].zfill(n)

def binary_division(n: int, M: str, Q: str):
    # Initialize variables
    A = "0" * n  # Remainder (initialized to 0)
    Q = Q.zfill(n)  # Ensure Q is n bits
    M = M.zfill(n)  # Ensure M is n bits
    Count = n

    while Count > 0:
        # Left shift A and Q
        A = A[1:] + Q[0]  # Shift left A
        Q = Q[1:] + "0"  # Shift left Q

        # A = A - M
        A = AddSub(A, M, "sub")

        if A[0] == "1":  # If A < 0 (most significant bit is 1)
            Q = Q[:-1] + "0"  # Set Q_0 to 0
            A = AddSub(A, M, "add")  # Restore A (A = A + M)
        else:
            Q = Q[:-1] + "1"  # Set Q_0 to 1

        # Decrement Count
        Count -= 1

    return Q, A  # Q is the quotient, A is the remainder

n = 4  # Number of bits
M = "0011"  # Divisor (3 in decimal)
Q = "1010"  # Dividend (10 in decimal)
quotient, remainder = binary_division(n, M, Q)
print("Quotient:", quotient)
print("Remainder:", remainder)